<?php
	echo '<title>jQuery Installed</title><div style="background: #e9ffed; border: 1px solid #b0dab7; padding: 15px;" align="center" >
	<font size="5" color="#182e7a">jQuery is installed successfully.</font><br /><br />
	<font size="4">jQuery is a JavaScript, so doesn\'t have an index page.<br /><br />
	jQuery is a fast, small, and feature-rich JavaScript library.
It makes things like HTML document traversal and manipulation, event handling, animation, and Ajax much simpler with an easy-to-use API that works across a multitude of browsers. With a combination of versatility and extensibility, jQuery has changed the way that millions of people write JavaScript.
</font></div>';

?>